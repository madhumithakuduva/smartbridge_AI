from flask import Flask, render_template, request
from prophet import Prophet
import pandas as pd
from sklearn.metrics import mean_absolute_error

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('new_index.html')

@app.route('/predict', methods=['POST'])
def predict():
    date = request.form.get('date')
    
    df = pd.read_csv('data.csv')
    
    # Preprocess the data
    df['ds'] = pd.to_datetime(df['Date'])
    df = df.rename(columns={'Gold Price in INR': 'y'})
    
    # Create and fit the Prophet model
    model = Prophet()
    model.fit(df)
    
    # Make future predictions
    future_dates = pd.date_range(start=date, periods=365, freq='D')
    future_df = pd.DataFrame({'ds': future_dates})
    forecast = model.predict(future_df)
    
    # Extract the predicted gold prices
    predictions = forecast[forecast['ds'] == date]['yhat']
    predicted_price = predictions.values[0]
    
    # Evaluate the model
    actual_values = df['y'].values
    predicted_values = forecast['yhat'].values[:len(df)]
    mae = mean_absolute_error(actual_values, predicted_values)
    
    return render_template('result.html', date=date, prediction=predicted_price, mae=mae)

if __name__ == '__main__':
    app.run(debug=True)
